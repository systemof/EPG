# ✅ Monitoramento de ECM com Alerta via Telegram (Enigma2 / ATTO)

Este guia cobre todo o processo de criação, configuração e ativação de um sistema de alerta automático via Telegram para falhas de ECM no OSCam.

---

## 🧾 1. Criar o Bot do Telegram

1. No Telegram, busque por `@BotFather`
2. Digite `/newbot`
3. Dê um nome e um username para o bot
4. Ao final, será fornecido um **Token** no formato:
   ```
   123456789:AA...SeuTokenAqui...
   ```
5. Copie esse token — será usado no script.

---

## 🧾 2. Obter o Chat ID

1. No navegador, acesse:
   ```
   https://api.telegram.org/bot<SEU_TOKEN>/getUpdates
   ```
2. Envie uma mensagem para o bot.
3. Recarregue o link acima.
4. Copie o valor de `"chat":{"id":...}` → esse é o `CHAT_ID`.

---

## 🧾 3. Configurar OSCam para gerar log

1. Edite o arquivo `oscam.conf`
2. Adicione (ou edite) a seção `[global]`:
   ```ini
   [global]
   logfile = /var/log/oscam.log
   ```

3. Reinicie o OSCam:
   ```bash
   killall oscam
   sleep 2
   /usr/bin/oscam -c /etc/tuxbox/config &
   ```

---

## 🧾 4. Instalar os scripts de alerta

### Coloque os dois arquivos no diretório:
```
/etc/oscam/
```

### Torne-os executáveis:
```bash
chmod +x /etc/oscam/ecm_alerta_telegram.sh
chmod +x /etc/oscam/ecm_alerta_loop.sh
```

---

## 🧾 5. Scripts

### `ecm_alerta_telegram.sh`:
- Lê as últimas 2000 linhas do log `/var/log/oscam.log`
- Detecta repetições de `timeout` ou `not found`
- Envia alerta via Telegram
- Evita alertas duplicados

### `ecm_alerta_loop.sh`:
- Executa o script de alerta a cada 60 segundos (loop infinito)

---

## 🧾 6. Executar o script em background (teste manual)

```bash
/etc/oscam/ecm_alerta_loop.sh &
```

---

## 🧾 7. Rodar o alerta automaticamente no boot

1. Edite `/etc/rc.local`
2. Antes do `exit 0`, adicione:
   ```bash
   /etc/oscam/ecm_alerta_loop.sh &
   ```

3. Torne o `rc.local` executável:
   ```bash
   chmod +x /etc/rc.local
   ```

---

## 🧾 8. Verificar funcionamento

- Você deverá receber uma mensagem no Telegram com a ECM com erro.
- Pode testar com:
   ```bash
   echo "ECM FAKE TEST 1802@DEADBEEF timeout (4000 ms)" >> /var/log/oscam.log
   bash /etc/oscam/ecm_alerta_telegram.sh
   ```

---

✅ Pronto! Agora o seu ATTO (ou STB com Enigma2) irá alertar você sempre que houver falha grave de ECM no OSCam.
