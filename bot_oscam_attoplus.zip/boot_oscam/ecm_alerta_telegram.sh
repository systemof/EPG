#!/bin/bash

LOG="/var/log/oscam.log"
TOKEN="o token aqui"
CHAT_ID="chat id aqui"
THRESHOLD=1
TMP="/tmp/ecm_check.log"
CACHE="/tmp/ecm_alerta_cache.txt"

tail -n 8000 "$LOG" > "$TMP"

# --- TIMEOUT ---
TIMEOUTS=$(grep -Ei "timeout" "$TMP"   | sed -n 's/.*:\(.*\)):.*timeout.*(\([0-9]\+\) ms).*/\1 \2/p'   | sort | uniq -c   | awk -v th=$THRESHOLD '$1 >= th {print $2 " " $3}')

for LINE in $TIMEOUTS; do
  ECM=$(echo "$LINE" | cut -d' ' -f1)
  TIME=$(echo "$LINE" | cut -d' ' -f2)
  if grep -q "TO_$ECM" "$CACHE"; then continue; fi
  MSG="🚨 *ALERTA OSCam - TIMEOUT*\n\n▸ Chave: \`$ECM\`\n▸ Tempo de resposta: $TIME ms"
  curl -s -X POST "https://api.telegram.org/bot$TOKEN/sendMessage" \
    -d chat_id="$CHAT_ID" \
    -d text="$MSG" \
    -d parse_mode="Markdown"
  echo "TO_$ECM" >> "$CACHE"
done

# --- NOT FOUND ---
NOTFOUNDS=$(grep -Ei "not found" "$TMP"   | sed -n 's/.*:\(.*\)):.*not found.*/\1/p'   | sort | uniq -c   | awk -v th=$THRESHOLD '$1 >= th {print $2}')

for ECM in $NOTFOUNDS; do
  if grep -q "NF_$ECM" "$CACHE"; then continue; fi
  MSG="🚫 *ALERTA OSCam - NOT FOUND*\n\n▸ Chave: \`$ECM\`"
  curl -s -X POST "https://api.telegram.org/bot$TOKEN/sendMessage" \
    -d chat_id="$CHAT_ID" \
    -d text="$MSG" \
    -d parse_mode="Markdown"
  echo "NF_$ECM" >> "$CACHE"
done

# --- CONNECTION FAILED ---
CONN_FAIL=$(grep -i "connection failed" "$TMP" | tail -1)
if [ -n "$CONN_FAIL" ] && ! grep -q "CF_ALERT" "$CACHE"; then
  MSG="🔌 *ALERTA OSCam - Connection Failed*\n\n\`$CONN_FAIL\`"
  curl -s -X POST "https://api.telegram.org/bot$TOKEN/sendMessage" \
    -d chat_id="$CHAT_ID" \
    -d text="$MSG" \
    -d parse_mode="Markdown"
  echo "CF_ALERT" >> "$CACHE"
fi

# --- READER OFFLINE ---
READER_OFFLINE=$(grep -Ei "reader.*offline" "$TMP" | tail -1)
if [ -n "$READER_OFFLINE" ] && ! grep -q "RO_ALERT" "$CACHE"; then
  MSG="📴 *ALERTA OSCam - Reader Offline*\n\n\`$READER_OFFLINE\`"
  curl -s -X POST "https://api.telegram.org/bot$TOKEN/sendMessage" \
    -d chat_id="$CHAT_ID" \
    -d text="$MSG" \
    -d parse_mode="Markdown"
  echo "RO_ALERT" >> "$CACHE"
fi

# Limpeza de cache com mais de 2 horas
find "$CACHE" -mmin +120 -exec rm -f {} \; 2>/dev/null
