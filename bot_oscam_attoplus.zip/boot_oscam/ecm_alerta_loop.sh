#!/bin/sh
while true; do
  /etc/oscam/ecm_alerta_telegram.sh
  sleep 1
done
