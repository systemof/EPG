#!/bin/sh
LOG1="/var/volatile/tmp/oscam.log"
LOG2="/tmp/oscam.log"
SCRIPT="/etc/tuxbox/config/ecm_alerta_telegram.sh"

while true; do
  tail -n0 -F "$LOG1" "$LOG2" 2>/dev/null | while read -r line; do
    echo "$line" | grep -q -E "not found|timeout|no matching reader|rejected group" && "$SCRIPT" "$line"
  done
done
