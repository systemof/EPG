#!/bin/sh
TOKEN="7882779642:AAEeGQYcMZ3Qnt508H8h1oY5ZUtqzZSu4tE"
CHAT_ID="675344294"

while true; do
    TEMP_LINE=$(grep "temperature" /proc/hisi/msp/pm_cpu 2>/dev/null)
    TEMP=$(echo "$TEMP_LINE" | grep -oE '[0-9]+' | head -1)

    if [ "$TEMP" -ge 70 ]; then
        MSG="🔥 ALERTA DE TEMPERATURA\n\nTemperatura atual: ${TEMP}°C"
        curl -s -X POST "https://api.telegram.org/bot$TOKEN/sendMessage" \
             -d chat_id="$CHAT_ID" -d text="$MSG"
    fi

    sleep 30
done
