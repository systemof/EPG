#!/bin/sh
# Envia alerta de ECM para Telegram com suporte a múltiplos tipos de erro e log
# Adaptado para Atto Turing

LOG1="/var/volatile/tmp/oscam.log"
LOG2="/tmp/oscam.log"
TOKEN="SEU_TOKEN"
CHAT_ID="SEU_CHAT_ID"

TEXT="$1"

extrair() {
  echo "$1" | grep -oE '([0-9A-F]{16})' | head -n1
}

if echo "$TEXT" | grep -q "not found"; then
  TIPO="NOT FOUND"
elif echo "$TEXT" | grep -q "timeout"; then
  TIPO="TIMEOUT"
elif echo "$TEXT" | grep -q "no matching reader"; then
  TIPO="NO MATCHING READER"
elif echo "$TEXT" | grep -q "rejected group"; then
  TIPO="REJECTED GROUP"
else
  TIPO="INVALID"
fi

ECM=$(extrair "$TEXT")
CAID=$(echo "$TEXT" | grep -oE 'CAID[ :]?[0-9A-F]{4}' | head -n1 | grep -oE '[0-9A-F]{4}')
PROVID=$(echo "$TEXT" | grep -oE 'PROVID[ :]?[0-9A-F]{6}' | head -n1 | grep -oE '[0-9A-F]{6}')
READER=$(echo "$TEXT" | grep -oP '(?<=by )\S+')
TIME=$(echo "$TEXT" | grep -oP '[0-9]+(?= ms)' | head -n1)

MSG="🚫 ALERTA OSCam - $TIPO\n\n▸ Chave: $ECM\n▸ Tempo de resposta: ${TIME} ms\n▸ CAID: $CAID\n▸ PROVID: $PROVID\n▸ Reader: $READER\n⏰ $(date '+%d/%m/%Y %H:%M:%S')"

curl -s -X POST "https://api.telegram.org/bot$TOKEN/sendMessage" -d chat_id="$CHAT_ID" -d text="$MSG"
